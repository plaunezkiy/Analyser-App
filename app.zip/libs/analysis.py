import pandas as pd


def read_data(file_name):
    data = pd.read_excel(file_name)
    df = pd.DataFrame(data)
    df.columns = [
        'Товар',
        'средний запас',
        '1 квартал',
        '2 квартал',
        '3 квартал',
        '4 квартал',
        'квартальное среднее'
    ]
    return df


def add_proportions(df):
    total_average_stock = df['средний запас'].sum()

    df['доля рынка'] = df.apply(
        lambda row: round(row['средний запас']/total_average_stock, 4),
        axis=1
    )
    return df


def get_abc(df):
    df = df.sort_values(by=['доля рынка'], ascending=False)
    total = 0

    def get_rank(item):
        nonlocal total
        total += item['доля рынка']
        if total < 0.75:
            return 'A'
        elif total < 0.95:
            return 'B'
        return 'C'

    df['abc'] = df.apply(lambda row: get_rank(row), axis=1)
    return df


def get_xyz(df):
    def get_v(row):
        sd = row[2:6].std(ddof=0)
        mean = row[2:6].mean()
        v = 100 * sd/mean
        return round(v, 1)

    def get_rank(row):
        if row['v'] < 10:
            return 'X'
        elif row['v'] < 25:
            return 'Y'
        return 'Z'

    df['v'] = df.apply(lambda row: get_v(row), axis=1)
    df = df.sort_values(by=['v'])
    df['xyz'] = df.apply(lambda row: get_rank(row), axis=1)
    return df


def get_abc_xyz_matrix(df):
    data = add_proportions(df)

    matrix = get_xyz(get_abc(data))
    matrix = matrix.drop(columns=[
        'средний запас',
        '1 квартал',
        '2 квартал',
        '3 квартал',
        '4 квартал',
        'квартальное среднее',
        'доля рынка',
        'v',
    ])

    # matrix = matrix.pivot_table(index='xyz', columns='abc',
    #                             values='index', aggfunc=list)
    return matrix


def get_bcg_matrix(df):
    def get_growth(row):
        growth = (row['3-4 кварталы'] - row['1-2 кварталы']) \
                 / row['1-2 кварталы']
        if growth > 10:
            return 'HIGH'
        return 'LOW'

    def get_share(row):
        nonlocal leader, matrix
        b = row['3-4 кварталы']
        share = b/leader
        if row['Товар'] == matrix.iloc[0]['Товар']:
            leader = b
        if share > 1:
            return 'HIGH'
        return 'LOW'

    matrix = pd.DataFrame()
    matrix['Товар'] = df['Товар']

    matrix['1-2 кварталы'] = df['1 квартал'] + df['2 квартал']
    matrix['3-4 кварталы'] = df['3 квартал'] + df['4 квартал']

    matrix['темп роста'] = matrix.apply(lambda row: get_growth(row), axis=1)

    # Дополнительная возможность отсортировать по реализации за 3-4 кварталы, чтобы найти лидера
    # matrix = matrix.sort_values(by=['3-4 quarters'], ascending=False)
    leader = matrix.iloc[1]['3-4 кварталы']
    matrix['доля рынка'] = matrix.apply(lambda row: get_share(row), axis=1)

    matrix = matrix.drop(columns=['1-2 кварталы', '3-4 кварталы'])

    # matrix = matrix.pivot_table(index='market growth', columns='market share',
    #                             values='index', aggfunc=list)
    return matrix


def reorder_data(abc_xyz, bcg):
    df = abc_xyz.set_index('Товар').join(bcg.set_index('Товар'))

    matrix = df[(df['abc'] == 'C') & (df['xyz'] == 'Z')]
    
    matrix = pd.concat([matrix, df[(df['abc'] == 'C') & (df['xyz'] == 'Y')].sort_values(by=['темп роста'])])
    
    matrix = pd.concat([matrix, df[(df['abc'] == 'A') & (df['xyz'] == 'Z')].sort_values(by=['темп роста'])])
    
    matrix = pd.concat([matrix, df[(df['abc'] == 'A') & (df['xyz'] == 'Y')]])
    
    matrix = pd.concat([matrix, df[(df['abc'] == 'B') & (df['xyz'] == 'Y')]])
    
    # stars matrix = pd.concat([matrix, df[(df['abc'] == 'C') & (df['xyz'] == 'Y')]])

    matrix = pd.concat([matrix, df[(df['abc'] == 'C') & (df['xyz'] == 'X')]])
    matrix = pd.concat([matrix, df[(df['abc'] == 'B') & (df['xyz'] == 'X')]])
    matrix = pd.concat([matrix, df[(df['abc'] == 'A') & (df['xyz'] == 'X')]])
    
    # dno
    df = df.reset_index()
    matrix = matrix.reset_index()

    items = matrix['Товар'].to_list()
    matrix = matrix.append(df.query('Товар not in @items'))

    return matrix


if __name__ == '__main__':
    fn = 'test.xlsx'
    clean_data = read_data(fn)
    processed_matrix = get_abc_xyz_matrix(clean_data)
    bcg_mat = get_bcg_matrix(clean_data)
    reordered = reorder_data(processed_matrix, bcg_mat)
    print(reordered)
    # print(bcg_mat)
